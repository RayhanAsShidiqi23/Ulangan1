<?php

include 'koneksi.php';

$nama= $_POST['nama'];
$email= $_POST['email'];
$notelepon= $_POST['no_telepon'];
$pekerjaan= $_POST['pekerjaan'];



 mysqli_query($dbconnect, "INSERT INTO `kontak` (`id`, `Nama`, `Email`, `No_telepon`, `Pekerjaan`) VALUES (NULL, '$nama', '$email', '$notelepon', '$pekerjaan')");

 header("location:user.php")
 ?>




